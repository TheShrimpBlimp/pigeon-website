# PIGEON screen-reader support

Screen-reader support is included in standard 0.5 builds and was introduced in 0.4. Earlier v0.3.1
firmware does not include it. A separate reader fork is no longer needed.

## Connect an FM1

1. Install a build with screen-reader support and connect the FM1 by USB.
2. Open [FM-1 Screen Reader](https://charlesvestal.github.io/fm1-reader/) in desktop
   Chrome or Edge and connect the matching MIDI port.
3. Choose browser speech or your own screen reader.
4. Use **WHERE** to read the current page and control values again.

If the reader requests a dictionary, download the matching
[dictionary](https://theshrimpblimp.com/pigeon/webapp/emu/words/84859cb5f4.json)
and load it into the reader manually.
Connecting the reader does not change samples, sessions or settings.

## Emulator

Enable **screen announcements**, then choose **My screen reader** or **Browser
voice**. Use **Read current screen** to repeat the page. Announcements start off.
Each emulator build includes its matching dictionary. The emulator remembers
announcement and output preferences in this browser. **Say it again** repeats the
last announcement; **Read current screen** requests all current controls.

Panel buttons and piano keys support screen-reader activation clicks. Tab to a
key and press Enter or Space to hold it; release to stop. Focused knobs respond
to arrow keys. Moving focus away releases a keyboard-held button or piano key.

## Announcements

- Navigation speaks the page title. Adjusting a control speaks its name and value.
- WHERE reads current controls and the selected step's chord. In the piano roll,
  it also includes the selected note's length and nudge.
- Recording arm state, transport changes, errors and confirmation choices are spoken.
- Queue WHERE reads the selection and the next eight chop numbers in order,
  including repeats. K3 announces the selected waiting position and chop.
- Chop announcements follow playback point, direction, cents, gain and crossfade.
- USB sampling announces destination, recording state, meter/clipping, remaining
  time, trim controls and save/retry confirmations. Scratch is excluded from 0.5.

Playback ticks, queue draining and decorative animations stay
silent. Empty note slots are identified without reading unused values. Errors
remain immediate; routine changes settle before being announced.

For the complete button map, see the [0.5 guide](PIGEON_V05_GUIDE.md).

## Credits

The integration uses [Charles Vestal's FM-1 Screen Reader protocol](https://github.com/charlesvestal/fm1-reader),
word generator and pronunciation module, under GPL-3.0-only. PIGEON supplies its
page descriptions and emulator interface. Build details and verification status
are in [development notes](PIGEON_V05_DEVELOPMENT.md).

Sequence tools announce the chosen action and its relevant controls. Expanded
step conditions are spoken by name. Holding ARP for FILL does not change pages
or produce continuous announcements.
