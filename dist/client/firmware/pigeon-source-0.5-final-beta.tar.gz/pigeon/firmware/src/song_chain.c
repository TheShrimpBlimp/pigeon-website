/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* A song uses the sequences of four saved projects, with the current sounds.
 * Sources are copied in the main loop before PLAY. The ISR changes only their
 * index and five timing parameters; the editable steps stay untouched.
 *
 * Lanes (1.2): a section (a row) names the slot each track plays (core.h chain_row_t). Each track reads its steps (with
 * CHANCE, RATCH, NUDGE), its automation and locks, LEN / DIV / SWING / GATE and QUANTIZE from its own slot's copy for
 * that track only; all four slots in use are copied before PLAY (chain_prepare: the four sources were there already
 * for whole rows, so lanes cost no more RAM). Sections keep one boundary for all four tracks: a section lasts `repeat`
 * loops of its clock track (chain_clock): the first track that is not silent there (track 1 when it plays: every song
 * before lanes counts as it did), or, every track silent, a 4/4 bar (CHAIN_SIL_*). At each section all four tracks
 * start together from their step 1, as rows always did.
 * A silent track ("-", CHAIN_SILENT) plays nothing in that section: at its start the track's sequenced notes are
 * released (seq_release, as at every section) and its automation goes back to the sound's own values (motion_restore);
 * no step, automation or lock of any slot plays there. Live keys and the arp still play it (the sound stays). */
/* Runtime caches only. Serialized FUNA projects retain all four lanes. */
#define CHAIN_PARTS UI_TRACK_COUNT
typedef struct {
    step_t step[CHAIN_PARTS][NSTEP];
    int16_t timing[CHAIN_PARTS][4];
    uint8_t qnt[CHAIN_PARTS];                       /* each track's QUANTIZE (P_SQNT) as saved */
    motion_store_t motion;
} chain_pattern_t;
static chain_config_t chain_config;
static struct {
    chain_pattern_t source[4];
    chain_config_t config;
    int16_t timing[NTRK][4];                 /* the editable LEN DIV SWING GATE and QUANTIZE, back on STOP */
    uint8_t qnt[NTRK];
    volatile uint8_t armed, running, row, remaining;
    uint8_t lane[NTRK];                      /* the slot each track plays in this section, CHAIN_SILENT none */
    uint8_t clk;                             /* the track whose loop counts the section (chain_clock) */
    uint8_t rec;
    uint32_t carry;
} chain;
#if FELUCCA_KO
/* Sources reuse chain.source. Prepared in the main loop; live launches publish
 * only a slot byte, never decode projects or access flash in the audio ISR. */
static uint8_t ko_pattern_sel, ko_copy_slot=255, ko_section, ko_pattern_mask;
static volatile uint8_t ko_launch_ready, ko_launch_mode, ko_launch_pending=255;
static volatile uint8_t ko_pattern_active=255, ko_pattern_commit=255;
static uint32_t ko_bar_pos;
#if FELUCCA_SAMPLER_ONLY
static volatile uint8_t ko_scene_pending __attribute__((section(".pool")));
static uint8_t ko_scene_mutes[3] __attribute__((section(".pool")));
static uint8_t ko_scene_restore __attribute__((section(".pool")));
#endif
#endif
/* a silent lane: its steps (empty: nothing plays) and its timing (a 4/4 bar of 1/16: the section's length when every
 * track is silent) */
static const step_t chain_silent[NSTEP] = {{{0}}};
#define CHAIN_SIL_LEN 16
#define CHAIN_SIL_DIV 2                      /* 1/16 */

static int ko_end_boundary(const track_t *t,uint32_t n);
static void seq_release(track_t *t);
static void seq_stop(void);
static uint32_t div_samples(uint32_t div);
static uint32_t step_samples(const track_t *t, uint32_t period, uint32_t idx);

static chain_row_t chain_row_of(uint32_t slot, uint32_t repeat)   /* a section with all four tracks on one slot */
{
    chain_row_t r;
    memset(r.slot, (int)slot, sizeof r.slot);
    r.repeat = (uint8_t)repeat;
    return r;
}
static void chain_defaults(chain_config_t *c)
{
    uint32_t i;
    memset(c, 0, sizeof *c);
    for (i = 0; i < CHAIN_ROWS; i++)
        c->row[i].repeat = 1;
}
static int chain_valid(const chain_config_t *c)
{
    uint32_t i, k;
    if (c->count > CHAIN_ROWS)
        return 0;
    for (i = 0; i < c->count; i++) {
        for (k = 0; k < NTRK; k++)
            if (c->row[i].slot[k] >
#if FELUCCA_SAMPLER_ONLY
                (k==3 && c->rsv[1]==0x4Du?7u:CHAIN_SILENT)
#else
                CHAIN_SILENT
#endif
                )
                return 0;
        if (!c->row[i].repeat || c->row[i].repeat > 16u)
            return 0;
    }
    return 1;
}
/* the chain of FUN6..FUN9 (rows {slot, repeat}) -> today's: each row a section with the four tracks on its slot. 0: not
 * a valid one (as chain_valid then) */
static int chain_from_v9(chain_config_t *c, const chain_v9_t *o)
{
    uint32_t i;
    chain_defaults(c);
    if (o->count > CHAIN_ROWS)
        return 0;
    for (i = 0; i < o->count; i++) {
        if (o->row[i].slot >= 4u || !o->row[i].repeat || o->row[i].repeat > 16u)
            return 0;
        c->row[i] = chain_row_of(o->row[i].slot, o->row[i].repeat);
    }
    c->count = o->count;
    return 1;
}
/* the track whose loops count section r's length: the first one not silent; every track silent: track 1 (a bar) */
static uint32_t chain_clock(const chain_row_t *r)
{
    uint32_t k;
    for (k = 0; k < (FELUCCA_SAMPLER_ONLY?SAMPLER_PARTS:NTRK); k++)
        if (r->slot[k] < CHAIN_SILENT)
            return k;
    return 0;
}
/* a track parameter a playing song sets from its slots (the editor and the pages leave it alone meanwhile) */
static int chain_owns(uint32_t id) { return (id >= P_SLEN && id <= P_SGATE) || id == P_SQNT; }
static const step_t *seq_steps(const track_t *t)
{
    uint32_t k = (uint32_t)(t - trk), s;
    if (!chain.running)
        return t->step;
    if(k>=CHAIN_PARTS)return chain_silent;
    s = chain.lane[k];
    return s < 4u ? chain.source[s].step[k] : chain_silent;
}
static void motion_restore(track_t *t);
/* a section starts (chain_start, chain_tick: once a section, not per block; not inlined: off the audio ISR's loop) */
static __attribute__((noinline)) void chain_apply(void)
{
    uint32_t i;
    const chain_row_t *r = &chain.config.row[chain.row];
    chain.clk = (uint8_t)chain_clock(r);
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        uint32_t s = i<CHAIN_PARTS?r->slot[i]:CHAIN_SILENT;
#if FELUCCA_SAMPLER_ONLY
        if(chain.config.rsv[1]==0x4Du){if(i<3)t->p[P_MUTE]=(r->slot[3]>>i)&1u;else s=CHAIN_SILENT;}
#endif
        chain.lane[i] = (uint8_t)(s < 4u ? s : CHAIN_SILENT);
        seq_release(t);
        motion_restore(t);
        if (s < 4u) {
            memcpy(&t->p[P_SLEN], chain.source[s].timing[i], sizeof chain.timing[i]);
            t->p[P_SQNT] = chain.source[s].qnt[i];
        } else {
            t->p[P_SLEN] = CHAIN_SIL_LEN;
            t->p[P_SDIV] = CHAIN_SIL_DIV;
            t->p[P_SSWING] = 0;
            t->p[P_SQNT] = 1;
        }
        t->seq_idx = (uint16_t)(t->p[P_SLEN] - 1);
        t->seq_pos = 0x7FFFFFFFu;
        t->rh_n = t->rskip_n = 0;
    }
}
static void chain_start(void)
{
    uint32_t i;
    if (!chain.armed)
        return;
#if FELUCCA_SAMPLER_ONLY
    ko_scene_pending=255;ko_scene_restore=chain.config.rsv[1]==0x4Du;
    if(ko_scene_restore)for(uint32_t k=0;k<3;k++)ko_scene_mutes[k]=(uint8_t)trk[k].p[P_MUTE];
#endif
    chain.rec = song.rec;
    song.rec = 0;
    for (i = 0; i < NTRK; i++) {
        memcpy(chain.timing[i], &trk[i].p[P_SLEN], sizeof chain.timing[i]);
        chain.qnt[i] = (uint8_t)trk[i].p[P_SQNT];
    }
#if FELUCCA_KO
    ko_bar_pos=0;
    if(ko_launch_mode) ko_pattern_active=chain.config.row[0].slot[0];
#endif
    chain.row = 0;
    chain.remaining = chain.config.row[0].repeat;
    chain.carry = 0;
    chain.running = 1;
    chain.armed = 0;
    chain_apply();
}
static void chain_stop(void)
{
    uint32_t i;
    chain.armed = 0;
#if FELUCCA_SAMPLER_ONLY
    ko_scene_pending=255;
    if(ko_scene_restore){for(uint32_t k=0;k<3;k++)trk[k].p[P_MUTE]=ko_scene_mutes[k];ko_scene_restore=0;}
#endif
#if FELUCCA_KO
    if(ko_launch_mode && chain.running && ko_pattern_active<4) ko_pattern_commit=ko_pattern_active;
    ko_launch_ready=ko_launch_mode=0;ko_launch_pending=ko_pattern_active=255;ko_bar_pos=0;
#endif
    if (!chain.running)
        return;
    for (i = 0; i < NTRK; i++) {
        memcpy(&trk[i].p[P_SLEN], chain.timing[i], sizeof chain.timing[i]);
        trk[i].p[P_SQNT] = chain.qnt[i];
    }
    song.rec = chain.rec;
    chain.running = 0;
}
static void chain_tick(uint32_t n)
{
#if FELUCCA_KO
    const track_t *t = &trk[chain.running ? chain.clk % NTRK : 0];
#else
    const track_t *t = &trk[chain.clk % NTRK];
#endif
    uint32_t length;
#if FELUCCA_KO
    if(ko_launch_ready && song.playing && (!chain.running || ko_launch_mode)) {
        uint32_t bar=16u*div_samples(2);
        ko_bar_pos+=n;
        int at_end=t->seq_idx+1u==(uint32_t)t->p[P_SLEN] && t->seq_pos+n>=step_samples(t,div_samples((uint32_t)t->p[P_SDIV]),t->seq_idx);
        if(ko_seq_end(t) && !chain.running)at_end=ko_end_boundary(t,n);
        int boundary=chain_config.rsv[0]==1 ? at_end : ko_bar_pos>=bar;
        if(boundary) {
            uint32_t carry=chain_config.rsv[0]==1 ? (ko_seq_end(t) && !chain.running?0:t->seq_pos+n-step_samples(t,div_samples((uint32_t)t->p[P_SDIV]),t->seq_idx)) : ko_bar_pos%bar;
            ko_bar_pos=carry;
            uint32_t slot=ko_launch_pending;
            if(slot<4u) {
                ko_launch_pending=255;ko_launch_mode=1;
                chain.config.count=1;chain.config.row[0]=chain_row_of(slot,1);
                if(!chain.running) { chain.armed=1;chain_start();ko_bar_pos=carry; }
                else {chain.row=0;chain.remaining=1;chain_apply();}
                ko_pattern_active=(uint8_t)slot;chain.carry=carry;
            }
        }
        if(ko_launch_mode) return; /* one pattern loops until another is launched */
    }
#endif
#if FELUCCA_SAMPLER_ONLY
    if(chain.running && !ko_launch_mode){
        uint32_t bar=16u*div_samples(2);ko_bar_pos+=n;
        int at_end=t->seq_idx+1u==(uint32_t)t->p[P_SLEN] && t->seq_pos+n>=step_samples(t,div_samples(t->p[P_SDIV]),t->seq_idx);
        int boundary=chain.config.rsv[0]==1?at_end:ko_bar_pos>=bar;
        if(ko_bar_pos>=bar)ko_bar_pos%=bar;
        if(boundary && ko_scene_pending<chain.config.count){
            chain.row=ko_scene_pending;ko_scene_pending=255;chain.remaining=chain.config.row[chain.row].repeat;chain.carry=0;chain_apply();return;
        }
    }
#endif
    if (!chain.running || t->seq_pos >= 0x7FFFFFFFu || t->seq_idx + 1u != (uint32_t)t->p[P_SLEN])
        return;
    length = step_samples(t, div_samples((uint32_t)t->p[P_SDIV]), t->seq_idx);
    if (t->seq_pos + n < length)
        return;
    if (chain.remaining > 1u) {
        chain.remaining--;
        return;
    }
    if (chain.row + 1u >= chain.config.count) {
        seq_stop();
        return;
    }
    chain.carry = t->seq_pos + n - length;
    chain.row++;
    chain.remaining = chain.config.row[chain.row].repeat;
    chain_apply();
}
