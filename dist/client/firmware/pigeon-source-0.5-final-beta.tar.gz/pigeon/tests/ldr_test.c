/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Host test of the Felucca update loader (firmware/loader/ldr_core.c): a fake
 * host serves a package over the SysEx protocol, the "device" flash starts as
 * another package's flash.bin (as if that firmware were installed).
 *   ldr_test OLD.fwsc NEW.fwsc */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define __attribute__(x)   /* (the sources' .pool sections: no Mach-O section names) */

#define FELUCCA_ID "ota-FM-1_900"
#define FELUCCA_OTA_DRYRUN 0

static uint8_t nor[0x100000], *logical;
static size_t logical_len;
static uint8_t rx[1024];
static uint32_t rx_len, rx_full, now_ms, requests, erases, bad_range, record_cleared, f0_asked;
static uint32_t flip_addr = 0xFFFFFFFFu, flip_seen, flip_on;   /* serve addr's flip_on-th reply with a byte changed */

static uint32_t pack7(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 8;
        while (nb >= 7) { out[o++] = acc & 0x7F; acc >>= 7; nb -= 7; }
    }
    if (nb) out[o++] = acc & 0x7F;
    return o;
}
static uint32_t unpack7h(const uint8_t *in, uint32_t n, uint8_t *out)
{
    uint32_t acc = 0, nb = 0, o = 0;
    while (n--) {
        acc |= (uint32_t)*in++ << nb;
        nb += 7;
        if (nb >= 8) { out[o++] = (uint8_t)acc; acc >>= 8; nb -= 8; }
    }
    return o;
}

static int ota_wire_send(const uint8_t *p, uint32_t n)
{
    uint8_t u[64], m[600];
    uint32_t addr, len, i, s = 0;
    unpack7h(p + 1, n - 2, u);
    if (u[2] == 0x11) return 0;
    addr = u[7] | u[8] << 8 | u[9] << 16 | (uint32_t)u[10] << 24;
    len = u[11] | u[12] << 8 | u[13] << 16;
    requests++;
    memcpy(m, "\x00\x59\x30", 3);
    m[3] = (uint8_t)(len + 8); m[4] = (uint8_t)((len + 8) >> 8); m[5] = 0; m[6] = 0;
    memcpy(m + 7, &addr, 4);
    m[11] = (uint8_t)len; m[12] = (uint8_t)(len >> 8); m[13] = 0;
    if (addr >= 0xE0000000u) {
        f0_asked += addr == 0xF0000000u;
        memset(m + 14, 0, len);
        memcpy(m + 14, "success", 8);
    } else {
        if (addr + len > logical_len) { printf("read past the package %#x\n", addr); exit(1); }
        memcpy(m + 14, logical + addr, len);
        if (addr == flip_addr && ++flip_seen == flip_on)
            m[14 + len / 2u] ^= 0x10;                /* a transfer error the frame checksum does not see */
    }
    for (i = 6; i < 14 + len; i++) s += m[i];
    m[14 + len] = (uint8_t)~s;
    rx_len = pack7(m, 15 + len, rx);
    rx_full = 1;
    return 0;
}
static int ota_frame_get(const uint8_t **p, uint32_t *n) { if (!rx_full) return 0; *p = rx; *n = rx_len; return 1; }
static void ota_frame_done(void) { rx_full = 0; }
static uint32_t ota_now_ms(void) { return now_ms; }
static void ota_idle(void) { now_ms++; }
static int ota_erase(uint32_t off) { (void)off; return -1; }
static int ota_prog(uint32_t off, const void *p, uint32_t n) { if (off < 0xE0000u || off+n > 0xE5000u) return -1; memcpy(nor+off,p,n); return 0; }
static int ota_fread(uint32_t off, void *p, uint32_t n) { memcpy(p, nor + off, n); return 0; }
static void ota_show(uint32_t step, int32_t code) { (void)step; (void)code; }
static void ota_commit(const uint8_t *parm) { (void)parm; }
#include "../firmware/src/ota.c"

static void (*flash_audit)(uint32_t) = NULL;
static int ldr_fread(uint32_t off, void *p, uint32_t n) { memcpy(p, nor + off, n); return 0; }
static int ldr_erase(uint32_t off)
{
    if (off < 0x4000u || off >= 0xFC000u || (off & 0xFFFu) || (off >= 0x97000u && off < 0xE0000u)) bad_range++;
    if (off < 0x4000u) { printf("ERASE IN THE HEAD %#x\n", off); exit(1); }
    erases++;
    memset(nor + off, 0xFF, 0x1000);
    if (flash_audit) flash_audit(off | 1u);
    return 0;
}
static int ldr_prog(uint32_t off, const void *p, uint32_t n)
{
    const uint8_t *s = p;
    uint32_t i;
    if (off < 0x4000u || off + n > 0x93000u || ((off & 0xFFu) + n) > 256u) bad_range++;
    for (i = 0; i < n; i++) nor[off + i] &= s[i];
    if (flash_audit) flash_audit(off);
    return 0;
}
static void ldr_record_clear(void) { record_cleared++; }
static void ldr_progress(uint32_t done, uint32_t total) { (void)done; (void)total; }
#include "../firmware/loader/ldr_core.c"

static uint8_t *load_logical(const char *path, size_t *len)
{
    FILE *f = fopen(path, "rb");
    uint8_t *raw = malloc(0x200000), *lg;
    size_t n, i;
    if (!f) { perror(path); exit(2); }
    n = fread(raw, 1, 0x200000, f);
    fclose(f);
    if (n < 20 * 48 + 0x400) { printf("%s: too short for a package\n", path); exit(2); }
    lg = malloc(n);
    for (i = 0; i < 20; i++) memcpy(lg + i * 47, raw + i * 48, 47);
    memcpy(lg + 20 * 47, raw + 20 * 48, n - 20 * 48);
    *len = n - 20;
    free(raw);
    return lg;
}

static uint32_t flash_off(const uint8_t *lg)        /* flash.bin offset in the logical image */
{
    uint8_t h[0x400];
    uint32_t i, n;
    memcpy(h, lg, sizeof h);
    ota_jl_enc(h, 0x40);
    n = ota_rd16(h + 8);
    for (i = 0; i < n; i++) {
        uint8_t *e = h + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 0) return ota_rd32(e + 8);
    }
    return 0;
}

static int check(const char *what, int ok) { printf("%-56s %s\n", what, ok ? "ok" : "FAIL"); return ok ? 0 : 1; }

static void set_fl_size(uint8_t *lg, uint32_t size)
{
    uint8_t h[0x40 + 11 * 0x50];
    uint32_t i, n;
    memcpy(h, lg, sizeof h);
    ota_jl_enc(h, 0x40);
    n = ota_rd16(h + 8);
    for (i = 0; i < n; i++) {
        uint8_t *e = h + 0x40 + i * 0x50u;
        ota_jl_enc(e, 0x50);
        if (ota_rd16(e) == 0)
            ota_wr32(e + 12, size);
        ota_jl_enc(e, 0x50);
    }
    ota_wr16(h + 2, ota_crc16(h + 0x40, n * 0x50u, 0));   /* (over the entries as stored) */
    ota_wr16(h, ota_crc16(h + 2, 0x3E, 0));
    ota_jl_enc(h, 0x40);
    memcpy(lg, h, 0x40 + n * 0x50u);
}

int main(int argc, char **argv)
{
    size_t olen;
    static uint8_t user[0x1000], reclaimed[KO_APP_DATA_HI-KO_APP_HI], top[KO_TOP_HI-KO_TOP_LO], extra[KO_EXTRA_HI-KO_GROW_LO];
    int expanded = argc > 3 && !strcmp(argv[3], "ko-storage");
    int extra_pool=0;
    uint8_t *old, head[0x4000];
    uint32_t ofo, nfo, i;
    int bad = 0, rc;
    if (argc < 3) { printf("usage: ldr_test OLD.fwsc NEW.fwsc\n"); return 2; }
    old = load_logical(argv[1], &olen);
    logical = load_logical(argv[2], &logical_len);
    ofo = flash_off(old);
    nfo = flash_off(logical);
    /* device: OLD installed, plus a valid update record at 0xE4F00 (Felucca's step 1) and 0xE8F00 (the stock
     * firmware's, a first install from it); user sample data in Felucca's store that looks like a record */
    memset(nor, 0xFF, sizeof nor);
    memcpy(nor, old + ofo, 0x93000);
    memcpy(head, nor, sizeof head);
    /* The general host suite exercises whichever package was built. Detect
     * its declared layout so preserved sample extents are not mistaken for
     * application bytes. An explicit argument still requires that profile. */
    if (argc <= 3) {
        uint32_t key; uint8_t descriptor[32];
        ldr_chip_key(&key);
        memcpy(descriptor,logical+nfo+LDR_APP_LO+KO_LAYOUT_ENTRY,32);
        ldr_sfc(descriptor,32,KO_LAYOUT_ENTRY,key);
        expanded = ota_memeq(descriptor+16,(const uint8_t *)KO_LAYOUT_NAME,8);
    }
    {
        uint32_t key;uint8_t descriptor[32];ldr_chip_key(&key);
        memcpy(descriptor,logical+nfo+LDR_APP_LO+KO_EXTRA_ENTRY,32);
        ldr_sfc(descriptor,32,KO_EXTRA_ENTRY,key);
        extra_pool=ota_memeq(descriptor+16,(const uint8_t *)KO_EXTRA_NAME,8);
    }
    {
        uint8_t r[112] = {0};
        r[2] = 0x0D; r[3] = 0x5A; r[4] = 0x01; r[5] = 0x5A; r[6] = 0x41; r[7] = 0x54;
        ota_wr16(r, ota_crc16(r + 2, 78, 0));
        memcpy(nor + 0xE4F00, r, sizeof r);
        memcpy(nor + 0xE8F00, r, sizeof r);
        for (i = 0; i < 0x1000u; i++) nor[0xA0000 + i] = (uint8_t)(i * 7u);
        memcpy(nor + 0xA0F00, r, sizeof r);
        memcpy(user, nor + 0xA0000, sizeof user);
    }
    { /* Board-size rejection must precede any erase or commit-marker change. */
        uint8_t keep[0x40+11*0x50];memcpy(keep,logical,sizeof keep);
        const uint32_t sizes[]={0x92000u,0x9D000u};
        for(uint32_t j=0;j<2;j++){
            set_fl_size(logical,sizes[j]);erases=0;rc=ldr_session();
            bad+=check("wrong board area refused without erasing application or marker",rc==-14&&!erases&&nor[0xE4F06]==0x41);
            memcpy(logical,keep,sizeof keep);requests=0;
        }
    }
    /* a damaged package (one byte deep in the app area): refused before anything is erased */
    {
        size_t at = nfo + 0x50123u;
        logical[at] ^= 0x01;
        erases = 0;
        rc = ldr_session();
        bad += check("damaged package (flash.bin CRC) refused, nothing erased", rc == -12 && erases == 0 &&
                     !memcmp(nor + 0x4000, old + ofo + 0x4000, 0x93000 - 0x4000) && nor[0xE4F06] == 0x41);
        logical[at] ^= 0x01;
        requests = 0;
    }
    if (expanded) {
        uint32_t key; uint8_t descriptor[32];
        ldr_chip_key(&key);
        memcpy(descriptor,logical+nfo+LDR_APP_LO+KO_LAYOUT_ENTRY,32);
        ldr_sfc(descriptor,32,KO_LAYOUT_ENTRY,key);
        bad+=check("expanded package advertises checked KO layout",ota_memeq(descriptor+16,(const uint8_t *)KO_LAYOUT_NAME,8)&&
            ota_rd32(descriptor+4)==KO_APP_HI&&ota_rd32(descriptor+8)==sizeof reclaimed);
        for(i=0;i<sizeof reclaimed;i++) reclaimed[i]=(uint8_t)(i*13u+1u);
        for(i=0;i<sizeof top;i++) top[i]=(uint8_t)(i*11u+3u);
        /* Sample bytes that resemble a valid update record must survive cleanup. */
        memcpy(top+0xF00,nor+0xE4F00,112);
        memcpy(nor+KO_APP_HI,reclaimed,sizeof reclaimed);
        memcpy(nor+KO_TOP_LO,top,sizeof top);
        if(extra_pool) {
            for(i=0;i<sizeof extra;i++)extra[i]=(uint8_t)(i*17u+9u);
            memcpy(nor+KO_GROW_LO,extra,sizeof extra);
        }
    }
    /* a sector that comes in different the second time (a transfer error after the check) is read again */
    flip_addr = nfo + 0x20000u; flip_on = 2; flip_seen = 0;
    rc = ldr_session();
    printf("  rc %d, %u requests, %u sector erases\n", rc, requests, erases);
    bad += check("install completes", rc == 0);
    bad += check("a sector changed in transfer after the check is read again", flip_seen == 3);
    flip_addr = 0xFFFFFFFFu;
    bad += check("app area and every reserved sample extent match",
        !memcmp(nor+0x4000,logical+nfo+0x4000,(extra_pool?KO_GROW_LO:expanded?KO_APP_HI:0x93000)-0x4000) &&
        (!extra_pool || (!memcmp(nor+KO_GROW_LO,extra,sizeof extra) &&
          !memcmp(nor+KO_EXTRA_HI,logical+nfo+KO_EXTRA_HI,KO_APP_HI-KO_EXTRA_HI))) &&
        (!expanded || (!memcmp(nor+KO_APP_DATA_HI,logical+nfo+KO_APP_DATA_HI,0x93000-KO_APP_DATA_HI) &&
          !memcmp(nor+KO_APP_HI,reclaimed,sizeof reclaimed) && !memcmp(nor+KO_TOP_LO,top,sizeof top))));
    bad += check("flash head [0, 0x4000) untouched", !memcmp(nor, head, sizeof head));
    bad += check("finish asked (0xF0000000)", f0_asked >= 1);
    bad += check("update records cleared (RAM + flash 0xE4F00, the stock firmware's 0xE8F00)",
                 record_cleared && nor[0xE4F06] == 0xFF && nor[0xE8F06] == 0xFF);
    bad += check("user data in Felucca's store that looks like a record is kept", !memcmp(nor + 0xA0000, user, sizeof user));
    bad += check("no write outside the allowed windows", bad_range == 0);
    /* same package again: nothing to erase */
    erases = 0; requests = 0;
    rc = ldr_session();
    bad += check("re-run with the same package erases nothing", rc == 0 && erases == 0);
    if (expanded) {
        uint8_t *next=logical; size_t next_len=logical_len;
        ota_wr32(nor+0xA0000,KO_BANK_MAGIC);
        logical=old; logical_len=olen; erases=0;
        rc=ldr_session();
        bad+=check("standard downgrade with active bank refused before erase",rc==-15&&erases==0&&
            !memcmp(nor+KO_APP_HI,reclaimed,sizeof reclaimed)&&!memcmp(nor+KO_TOP_LO,top,sizeof top));
        logical=next; logical_len=next_len;
    }
    /* a package for another chip key is refused before any erase */
    {
        uint8_t save = logical[nfo + 0x4000 + 5];
        logical[nfo + 0x4000 + 5] ^= 0x5A;           /* app area head no longer decrypts */
        memcpy(nor, old + ofo, 0x93000);
        erases = 0;
        rc = ldr_session();
        bad += check("foreign key / damaged app head refused, nothing erased", rc == -6 && erases == 0);
        logical[nfo + 0x4000 + 5] = save;
    }
    printf("%s\n", bad ? "LOADER TEST FAILED" : "loader test passed");
    return bad != 0;
}
