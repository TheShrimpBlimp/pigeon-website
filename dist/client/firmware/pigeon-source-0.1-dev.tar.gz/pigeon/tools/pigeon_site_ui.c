/* SPDX-License-Identifier: GPL-3.0-only */
/* Capture real firmware pixels with host fixture audio; no image generation. */
#define KO_TEST_MAIN unused_ko_test_main
#include "../tests/ko_test.c"
int main(int argc,char **argv) {
    if(argc!=2)return 2;
    ui_power_on();memset(ko_states,0,sizeof ko_states);
    memset(ko_flash,255,sizeof ko_flash);slc_store_boot();fixture(0,0);fixture(1,1);
    menu_put(MI_KO,1);ko_states[0].on=1;ko_setup();render_blocks(32);song.sel=0;go_home();
    ko_palette_on=1;palette_set(0);ko_select(2);ko.zoom=2;ko.view=0;screen_save(argv[1],"waveform");
    ko_seq[0].enabled=1;trk[0].p[P_SLEN]=16;ko_seq[0].cursor=6;
    for(uint32_t i=0;i<16;i++){trk[0].step[i]=(step_t){.note={60+i%4},.n=(i%4==0 || i==6),.time=ST_NOTE,.vel=100};}
    ko.view=7;screen_save(argv[1],"sequencer");
    ko.view=27;ko_sync[0]=(ko_sync_t){.beats=4,.samples=44100,.on=1};screen_save(argv[1],"tempo-sync");
    return 0;
}
